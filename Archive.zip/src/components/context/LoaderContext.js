import React from 'react';
const LoaderContext = React.createContext(false);

export default LoaderContext;