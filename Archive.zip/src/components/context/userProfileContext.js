import React from 'react';
const userProfileContext = React.createContext('');

export default userProfileContext;